Report Code (Python 3.5) 2/5/2018


SUMMARY
---------------------------------------------
This code was written, in conjunction with excerpts from online forums and workshop material, to complete the necessary pre-processing, data integration and visualisation

NOTEBOOK OVERVIEW
----------------------------------------------
The jupyter notebook file contains subheadings which indicate the relevant stage of the report that is being completed

NOTEBOOK STRUCTURE
---------------------------------------------
- First, socio-economic dataset is built, through merging together multiple csv files which represent various Excel spreadsheets. These datasets are cleaned to be of the same format and finally merged together.
- Next, the crime dataset is built, through grouping the data by the Suburb and doing some basic cleaning of the data. 
- The two datasets are then integrated into a new dataset for visualisation
- The geopy library is now used to find the respect longitude and latitudes for every Suburb to assist with plotting of the data (Later realised this step not required for plotting geographic heatmap)
- The K-NN algorithm is calculates, using the 5 nearest neighbours. The code is used from Workshop 8 whilst the basic discretisation was written by myself, where values above the 75th percentile value were classes as high_crime, and the rest as low_crime. The algorithm was then converted into a heatmap to examine the false positives, false negatives, true positives, true negatives using the confusion matrix built in package from sklearn. The confusion matrix was then made into a hetamap using the seaborn package.
- Outlier detection and anlalysis was next completed. The outlier detection code was adapted from :https://stackoverflow.com/questions/23199796/detect-and-exclude-outliers-in-pandas-dataframe. Then, a boxplot was created for a visual representation of the outliers.
- Scatter plot with Linear regression line was completed through using code from https://github.com/OpenGenus/quark/blob/master/code/code/artificial_intelligence/src/Linear_Regression/linear_regression.py. The variables were adjusted accordingly to my datasets
- The parallel coordinates graph was made through first normalising variables and then plotting them to show data aggregation (clumps) as well as correlations.
- The final geographic heatmap was made through using a Victorian based shapefile, along with modifications to the code accessed from https://github.com/jamalmoir/notebook_playground/blob/master/uk_2015_houseprice.ipynb. The shapefile was accessed at :http://www.abs.gov.au/AUSSTATS/abs@.nsf/DetailsPage/1270.0.55.003July%202011

BUILT IN LIBRARIES THAT WERE USED
------------------------------------------------
- pandas
- plotly (for geographic heatmap)
- numpy
- matplotlib
- sklearn (linear regression, K-NN)
- geopandas (geographic basemap)
- geopy (latitude,longitude of suburbs)
- seaborn